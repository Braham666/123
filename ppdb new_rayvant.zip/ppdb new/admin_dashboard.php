<?php
require_once 'includes/auth.php';
require_once 'config/database.php';

// Check if user is admin
checkAdmin();

// Handle user verification
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['verify_user'])) {
    $user_id = $_POST['user_id'];
    $action = $_POST['action'];
    
    try {
        if ($action == 'verify') {
            $stmt = $pdo->prepare("UPDATE users SET is_verified = TRUE WHERE id = ?");
            $stmt->execute([$user_id]);
            $success = "Pengguna berhasil diverifikasi!";
        } else if ($action == 'reject') {
            // Delete associated student data first
            $stmt = $pdo->prepare("DELETE FROM students WHERE user_id = ?");
            $stmt->execute([$user_id]);
            
            // Then delete the user
            $stmt = $pdo->prepare("DELETE FROM users WHERE id = ?");
            $stmt->execute([$user_id]);
            $success = "Pengguna berhasil ditolak dan dihapus!";
        }
    } catch(PDOException $e) {
        $error = "Gagal memproses pengguna: " . $e->getMessage();
    }
}

// Handle student status update
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_status'])) {
    $student_id = $_POST['student_id'];
    $status = $_POST['status'];
    
    try {
        $stmt = $pdo->prepare("UPDATE students SET status = ? WHERE id = ?");
        $stmt->execute([$status, $student_id]);
        $success = "Status siswa berhasil diperbarui!";
    } catch(PDOException $e) {
        $error = "Gagal memperbarui status: " . $e->getMessage();
    }
}

// Get all unverified users
try {
    $stmt = $pdo->query("SELECT * FROM users WHERE is_verified = FALSE AND role = 'user' ORDER BY created_at DESC");
    $unverifiedUsers = $stmt->fetchAll();
} catch(PDOException $e) {
    $error = "Gagal mengambil data pengguna yang belum terverifikasi: " . $e->getMessage();
}

// Get all students with user information
try {
    $stmt = $pdo->prepare("
        SELECT s.*, u.username, u.email, u.is_verified 
        FROM students s 
        JOIN users u ON s.user_id = u.id 
        ORDER BY s.created_at DESC
    ");
    $stmt->execute();
    $students = $stmt->fetchAll();
} catch(PDOException $e) {
    $error = "Gagal mengambil data siswa: " . $e->getMessage();
}

// Get statistics
try {
    // Total students
    $stmt = $pdo->query("SELECT COUNT(*) FROM students");
    $totalStudents = $stmt->fetchColumn();
    
    // Students by status
    $stmt = $pdo->query("SELECT status, COUNT(*) as count FROM students GROUP BY status");
    $statusCounts = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);
    
    // Total users
    $stmt = $pdo->query("SELECT COUNT(*) FROM users");
    $totalUsers = $stmt->fetchColumn();
    
    // Unverified users
    $stmt = $pdo->query("SELECT COUNT(*) FROM users WHERE is_verified = FALSE AND role = 'user'");
    $unverifiedCount = $stmt->fetchColumn();
    
    // Recent registrations (last 7 days)
    $stmt = $pdo->query("SELECT COUNT(*) FROM students WHERE created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)");
    $recentRegistrations = $stmt->fetchColumn();
} catch(PDOException $e) {
    $error = "Gagal mengambil statistik: " . $e->getMessage();
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Admin - Sistem PPDB</title>
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700;800&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.7.2/font/bootstrap-icons.css" rel="stylesheet">
    <link href="assets/css/style.css" rel="stylesheet">
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark">
        <div class="container">
            <a class="navbar-brand" href="#">
                <i class="bi bi-mortarboard-fill me-2"></i>
                PPDB Admin
            </a>
            <div class="navbar-nav ms-auto">
                <a class="nav-item nav-link" href="dashboard.php">
                    <i class="bi bi-person-circle me-1"></i>
                    Dashboard User
                </a>
                <span class="nav-item nav-link">
                    <i class="bi bi-person me-1"></i>
                    Selamat datang, <?php echo htmlspecialchars($_SESSION['username']); ?>
                </span>
                <a class="nav-item nav-link" href="logout.php">
                    <i class="bi bi-box-arrow-right me-1"></i>
                    Keluar
                </a>
            </div>
        </div>
    </nav>

    <div class="container mt-4">
        <?php if (isset($success)): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <?php echo $success; ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>
        
        <?php if (isset($error)): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <?php echo $error; ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <!-- Statistics Cards -->
        <div class="row mb-4">
            <div class="col-md-3">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">
                            <i class="bi bi-people-fill me-2"></i>
                            Total Siswa
                        </h5>
                        <h2 class="card-text"><?php echo $totalStudents; ?></h2>
                        <small class="text-muted">Total pendaftar</small>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">
                            <i class="bi bi-person-badge-fill me-2"></i>
                            Total Pengguna
                        </h5>
                        <h2 class="card-text"><?php echo $totalUsers; ?></h2>
                        <small class="text-muted">Total akun terdaftar</small>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">
                            <i class="bi bi-clock-history me-2"></i>
                            Pendaftaran Menunggu
                        </h5>
                        <h2 class="card-text"><?php echo $statusCounts['pending'] ?? 0; ?></h2>
                        <small class="text-muted">Menunggu verifikasi</small>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">
                            <i class="bi bi-person-x-fill me-2"></i>
                            Pengguna Belum Terverifikasi
                        </h5>
                        <h2 class="card-text"><?php echo $unverifiedCount; ?></h2>
                        <small class="text-muted">Perlu verifikasi admin</small>
                    </div>
                </div>
            </div>
        </div>

        <!-- Unverified Users Section -->
        <?php if (!empty($unverifiedUsers)): ?>
        <div class="card mb-4">
            <div class="card-header bg-warning text-white">
                <h4 class="mb-0">
                    <i class="bi bi-exclamation-triangle-fill me-2"></i>
                    Pengguna Belum Terverifikasi
                </h4>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>Username</th>
                                <th>Email</th>
                                <th>Tanggal Daftar</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($unverifiedUsers as $user): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($user['username']); ?></td>
                                    <td><?php echo htmlspecialchars($user['email']); ?></td>
                                    <td><?php echo date('d M Y H:i', strtotime($user['created_at'])); ?></td>
                                    <td>
                                        <form method="POST" action="" class="d-inline">
                                            <input type="hidden" name="user_id" value="<?php echo $user['id']; ?>">
                                            <input type="hidden" name="action" value="verify">
                                            <button type="submit" name="verify_user" class="btn btn-success btn-sm">
                                                <i class="bi bi-check-circle-fill me-1"></i>
                                                Verifikasi
                                            </button>
                                        </form>
                                        <form method="POST" action="" class="d-inline">
                                            <input type="hidden" name="user_id" value="<?php echo $user['id']; ?>">
                                            <input type="hidden" name="action" value="reject">
                                            <button type="submit" name="verify_user" class="btn btn-danger btn-sm" 
                                                    onclick="return confirm('Apakah Anda yakin ingin menolak pengguna ini?')">
                                                <i class="bi bi-x-circle-fill me-1"></i>
                                                Tolak
                                            </button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <?php endif; ?>

        <!-- Students Table -->
        <div class="card">
            <div class="card-header bg-primary text-white">
                <h4 class="mb-0">
                    <i class="bi bi-table me-2"></i>
                    Semua Pendaftaran Siswa
                </h4>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>Nama Siswa</th>
                                <th>NISN</th>
                                <th>Didaftarkan Oleh</th>
                                <th>Email</th>
                                <th>Status Pengguna</th>
                                <th>Status Pendaftaran</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($students as $student): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($student['full_name']); ?></td>
                                    <td><?php echo htmlspecialchars($student['nisn']); ?></td>
                                    <td><?php echo htmlspecialchars($student['username']); ?></td>
                                    <td><?php echo htmlspecialchars($student['email']); ?></td>
                                    <td>
                                        <span class="badge bg-<?php echo $student['is_verified'] ? 'success' : 'warning'; ?>">
                                            <?php echo $student['is_verified'] ? 'Terverifikasi' : 'Belum Terverifikasi'; ?>
                                        </span>
                                    </td>
                                    <td>
                                        <span class="badge bg-<?php 
                                            echo $student['status'] == 'accepted' ? 'success' : 
                                                ($student['status'] == 'rejected' ? 'danger' : 'warning'); 
                                        ?>">
                                            <?php 
                                            echo $student['status'] == 'accepted' ? 'Diterima' : 
                                                ($student['status'] == 'rejected' ? 'Ditolak' : 'Menunggu'); 
                                            ?>
                                        </span>
                                    </td>
                                    <td>
                                        <form method="POST" action="" class="d-inline">
                                            <input type="hidden" name="student_id" value="<?php echo $student['id']; ?>">
                                            <select name="status" class="form-select form-select-sm d-inline-block w-auto" onchange="this.form.submit()">
                                                <option value="pending" <?php echo $student['status'] == 'pending' ? 'selected' : ''; ?>>Menunggu</option>
                                                <option value="accepted" <?php echo $student['status'] == 'accepted' ? 'selected' : ''; ?>>Terima</option>
                                                <option value="rejected" <?php echo $student['status'] == 'rejected' ? 'selected' : ''; ?>>Tolak</option>
                                            </select>
                                            <input type="hidden" name="update_status" value="1">
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Enable tooltips
        var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
        var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
            return new bootstrap.Tooltip(tooltipTriggerEl)
        })
    </script>
</body>
</html> 