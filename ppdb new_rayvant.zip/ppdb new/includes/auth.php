<?php
session_start();

// Function to check if user is logged in
function checkLogin() {
    if (!isset($_SESSION['user_id'])) {
        $_SESSION['error'] = "Please login first";
        header("Location: login.php");
        exit();
    }
}

// Function to check if user is admin
function checkAdmin() {
    if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
        $_SESSION['error'] = "Access denied. Admin only.";
        header("Location: login.php");
        exit();
    }
}
?> 