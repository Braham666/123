<?php
require_once 'includes/auth.php';
require_once 'config/database.php';

// Check if user is logged in
checkLogin();

// Get user verification status
try {
    $stmt = $pdo->prepare("SELECT is_verified, email FROM users WHERE id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $user = $stmt->fetch();
    $isVerified = $user['is_verified'];
    $userEmail = $user['email'];
} catch(PDOException $e) {
    $error = "Gagal mengambil status pengguna: " . $e->getMessage();
}

// Get student data if exists
try {
    $stmt = $pdo->prepare("SELECT * FROM students WHERE user_id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $student = $stmt->fetch();
} catch(PDOException $e) {
    $error = "Gagal mengambil data siswa: " . $e->getMessage();
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['submit'])) {
    if (!$isVerified) {
        $error = "Akun Anda perlu diverifikasi oleh admin sebelum dapat mengirimkan data siswa.";
    } else if ($student) {
        $error = "Anda sudah mengirimkan data siswa. Hanya satu pengiriman yang diizinkan per pengguna.";
    } else {
        // Process form submission
        $full_name = $_POST['full_name'];
        $nisn = $_POST['nisn'];
        $birth_date = $_POST['birth_date'];
        $gender = $_POST['gender'];
        $address = $_POST['address'];
        $phone = $_POST['phone'];
        $school_origin = $_POST['school_origin'];
        
        // Validate NISN
        if (strlen($nisn) != 10 || !is_numeric($nisn)) {
            $error = "NISN harus terdiri dari 10 digit angka";
        } else {
            try {
                $stmt = $pdo->prepare("
                    INSERT INTO students (
                        user_id, full_name, nisn, birth_date, gender, address, 
                        phone, school_origin, status
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'pending')
                ");
                
                $stmt->execute([
                    $_SESSION['user_id'], $full_name, $nisn, $birth_date, $gender,
                    $address, $phone, $school_origin
                ]);
                
                $success = "Data siswa berhasil dikirim!";
                header("Location: dashboard.php");
                exit();
            } catch(PDOException $e) {
                $error = "Gagal mengirim data: " . $e->getMessage();
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Pengguna - Sistem PPDB</title>
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700;800&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/css/style.css" rel="stylesheet">
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark">
        <div class="container">
            <a class="navbar-brand" href="#">Sistem PPDB</a>
            <div class="navbar-nav ms-auto">
                <span class="nav-item nav-link">Selamat datang, <?php echo htmlspecialchars($_SESSION['username']); ?></span>
                <a class="nav-item nav-link" href="logout.php">Keluar</a>
            </div>
        </div>
    </nav>

    <div class="container mt-4">
        <?php if (isset($success)): ?>
            <div class="alert alert-success"><?php echo $success; ?></div>
        <?php endif; ?>
        
        <?php if (isset($error)): ?>
            <div class="alert alert-danger"><?php echo $error; ?></div>
        <?php endif; ?>

        <div class="row">
            <div class="col-md-4">
                <div class="card mb-4">
                    <div class="card-header">
                        <h4>Status Akun</h4>
                    </div>
                    <div class="card-body">
                        <p>Username: <?php echo htmlspecialchars($_SESSION['username']); ?></p>
                        <p>Email: <?php echo htmlspecialchars($userEmail); ?></p>
                        <p>Status Verifikasi: 
                            <span class="badge bg-<?php echo $isVerified ? 'success' : 'warning'; ?>">
                                <?php echo $isVerified ? 'Terverifikasi' : 'Belum Terverifikasi'; ?>
                            </span>
                        </p>
                        <?php if (!$isVerified): ?>
                            <div class="alert alert-warning">
                                Akun Anda perlu diverifikasi oleh admin sebelum dapat mengirimkan data siswa.
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            
            <div class="col-md-8">
                <?php if ($student): ?>
                    <div class="card">
                        <div class="card-header">
                            <h4>Data Siswa</h4>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-6">
                                    <p><strong>Nama Lengkap:</strong> <?php echo htmlspecialchars($student['full_name']); ?></p>
                                    <p><strong>NISN:</strong> <?php echo htmlspecialchars($student['nisn']); ?></p>
                                    <p><strong>Tanggal Lahir:</strong> <?php echo date('d M Y', strtotime($student['birth_date'])); ?></p>
                                    <p><strong>Jenis Kelamin:</strong> <?php echo htmlspecialchars($student['gender'] == 'male' ? 'Laki-laki' : 'Perempuan'); ?></p>
                                    <p><strong>Alamat:</strong> <?php echo htmlspecialchars($student['address']); ?></p>
                                </div>
                                <div class="col-md-6">
                                    <p><strong>Nomor Telepon:</strong> <?php echo htmlspecialchars($student['phone']); ?></p>
                                    <p><strong>Asal Sekolah:</strong> <?php echo htmlspecialchars($student['school_origin']); ?></p>
                                </div>
                            </div>
                            <div class="mt-3">
                                <p><strong>Status Pendaftaran:</strong> 
                                    <span class="badge bg-<?php 
                                        echo $student['status'] == 'accepted' ? 'success' : 
                                            ($student['status'] == 'rejected' ? 'danger' : 'warning'); 
                                    ?>">
                                        <?php 
                                        echo $student['status'] == 'accepted' ? 'Diterima' : 
                                            ($student['status'] == 'rejected' ? 'Ditolak' : 'Menunggu'); 
                                        ?>
                                    </span>
                                </p>
                            </div>
                        </div>
                    </div>
                <?php elseif ($isVerified): ?>
                    <div class="card">
                        <div class="card-header">
                            <h4>Kirim Data Siswa</h4>
                        </div>
                        <div class="card-body">
                            <form method="POST" action="">
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="full_name" class="form-label">Nama Lengkap</label>
                                            <input type="text" class="form-control" id="full_name" name="full_name" required>
                                        </div>
                                        <div class="mb-3">
                                            <label for="nisn" class="form-label">NISN</label>
                                            <input type="text" class="form-control" id="nisn" name="nisn" 
                                                pattern="[0-9]{10}" 
                                                title="NISN harus terdiri dari 10 digit angka" 
                                                maxlength="10" 
                                                minlength="10" 
                                                required>
                                            <div class="form-text">NISN harus terdiri dari 10 digit angka</div>
                                        </div>
                                        <div class="mb-3">
                                            <label for="birth_date" class="form-label">Tanggal Lahir</label>
                                            <input type="date" class="form-control" id="birth_date" name="birth_date" required>
                                        </div>
                                        <div class="mb-3">
                                            <label for="gender" class="form-label">Jenis Kelamin</label>
                                            <select class="form-select" id="gender" name="gender" required>
                                                <option value="male">Laki-laki</option>
                                                <option value="female">Perempuan</option>
                                            </select>
                                        </div>
                                        <div class="mb-3">
                                            <label for="address" class="form-label">Alamat</label>
                                            <textarea class="form-control" id="address" name="address" rows="3" required></textarea>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="phone" class="form-label">Nomor Telepon</label>
                                            <input type="tel" class="form-control" id="phone" name="phone" required>
                                        </div>
                                        <div class="mb-3">
                                            <label for="school_origin" class="form-label">Asal Sekolah</label>
                                            <input type="text" class="form-control" id="school_origin" name="school_origin" required>
                                        </div>
                                    </div>
                                </div>
                                <button type="submit" name="submit" class="btn btn-primary">Kirim</button>
                            </form>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html> 